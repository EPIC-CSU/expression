/*****************************************************************\
*                                                                *
*  Copyright (C) Regents of University of California, 2003       *
*  This source code is a part of EXPRESSION project and is       *
*  copyrighted by the Regents of the University of California,   *
*  Irvine.                                                       *
*  The authors hereby grant permission to use this description   *
*  and its documentation for educational and non-commercial      *
*  purpose under the BSD license                                 *
*  (http://www.cecs.uci.edu/~express/BSD_License.txt). 	         *
*  The source code comes with no warranty and no author or       *
*  distributor accepts any responsibility for the consequences   *
*  of its use. Permission is granted to distribute this file in  *
*  compiled or executable form under the same conditions that    *
*  apply for source code. Permission is granted	to anyone to     *
*  make or distribute copies of this source code, either as      *
*  received or modified, in any medium, provided that all        *
*  copyright notices, permission and non warranty notices are    *
*  preserved, and that the distributor grants the recipient      *
*  permission for further redistribution as permitted by this    *
*  document. No written agreement, license, or royalty fee is    *
*  required for authorized use of this software.                 *
*                                                                *
*******************************************************************/
// Text2.cpp : test
//
/////////////////////////////////////////////////////////////////////////////
/**
 * Description : 
**/
/////////////////////////////////////////////////////////////////////////////
//
// This file is copyrighted by the Regents of the
// University of California, Irvine. The following terms apply to
// all files associated with the description unless explicitly
// disclaimed in individual files.
// The authors hereby grant permission to use this description and
// its documentation for educational and non-commercial purpose.
// No written agreement, license, or royalty fee is required for
// authorized use of this software.
//
/////////////////////////////////////////////////////////////////////////////
//
// IN NO EVENT SHALL THE AUTHORS OR DISTRIBUTORS BE
// LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL,
// INCIDENTAL, OR CONSEQUENTIAL DAMAGES ARISING OUT
// OF THE USE OF THIS DESCRIPTION, ITS DOCUMENTATION,
// OR ANY DERIVATIVES THEREOF, EVEN IF THE AUTHORS HAVE
// BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// THE AUTHORS AND DISTRIBUTORS SPECIFICALLY
// DISCLAIM ANY WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
// AND NON-INFRINGEMENT. THIS DESCRIPTION IS PROVIDED
// ON AN "AS IS" BASIS, AND THE AUTHORS AND
// DISTRIBUTORS HAVE NO OBLIGATION TO PROVIDE
// MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
// MODIFICATIONS.
//
/////////////////////////////////////////////////////////////////////////////
/**
 * ACES Lab - University of California, Irvine - USA
 *
 * Created:	
 * Author:		
 * Email:		aces@ics.uci.edu
 *
 * $Modtime: 5/23/02 5:27p $
 * $Revision: 14 $
 * $Author: Radu $
 *
**/
/////////////////////////////////////////////////////////////////////////////

// Test file
// Add some lines


/*#include <stdio.h>*/

void main(void)
/*{
	printf("Hello!\n");*/
}


