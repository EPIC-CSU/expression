#include <stdio.h>

void DEBUG_PRINT(int x)
{
  printf(" %d\n", x);
}
